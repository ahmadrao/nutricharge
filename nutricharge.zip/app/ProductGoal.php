<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductGoal extends Model
{
    protected $fillable = ['name'];
}
