<script src="{{ asset('js/iziToast.js') }}"></script>
@include('vendor.lara-izitoast.toast')
<!-- jQuery -->
<script src="{{asset('js/libs.js')}}"></script>
@yield('scripts')
