<footer>
        <div class="row">
            <div class="col-lg-12">
                <p>Copyright &copy; Your Website Nurtricharge <?php echo e(\Carbon\Carbon::now()->year); ?></p>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </footer>