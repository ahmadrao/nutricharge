<?php $__env->startSection('content'); ?>
    <h1>CATEGORIES</h1>


    <div class="col-sm-6">
        <h3>Create Category</h3>


        <?php echo Form::open(['method'=>'POST', 'action'=>'AdminCategoriesController@store']); ?>

        <div class="form-group">
            <?php echo Form::label('name', 'Name:'); ?>

            <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Create Category', ['class'=> 'btn btn-primary']); ?>

        </div>

        <?php echo Form::close(); ?>


    </div>
    <div class="col-sm-6">


        <table class="table table-dark">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Created At</th>
                <th scope="col">Updated At</th>
                <th scope="col">EDIT</th>
                <th scope="col">DELETE</th>
            </tr>
            </thead>
            <tbody>

            <?php if($categories): ?>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($category->id); ?></th>
                        <td><?php echo e($category->name); ?></td>
                        <td><?php echo e($category->created_at ? $category->created_at->diffForHumans() : 'NOT PROVIDED'); ?></td>
                        <td><?php echo e($category->updated_at ? $category->updated_at->diffForHumans() : 'NOT PROVIDED'); ?></td>
                        <td><a href="/admin/categories/<?php echo e($category->id); ?>/edit" class="btn btn-outline-primary">Edit</a>
                        </td>
                        <td>
                            <?php echo Form::open(['method'=>'DELETE', 'action'=>['AdminCategoriesController@destroy', $category->id]]); ?>


                            <div class="form-group">
                                <?php echo Form::submit('Delete', ['class'=> 'btn btn-outline-danger']); ?>

                            </div>

                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            </tbody>
        </table>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>