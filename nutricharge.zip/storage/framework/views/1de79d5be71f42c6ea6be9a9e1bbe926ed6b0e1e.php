<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.admin.tinyeditor', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <h1>Create Product</h1>
    <div class="row">
        <?php echo Form::open(['method'=>'POST', 'action'=>'AdminProductsController@store','files'=>true]); ?>

        <div class="form-group">
            <?php echo Form::label('title', 'Title:'); ?>

            <?php echo Form::text('title', null, ['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('category_id', 'Category:'); ?>

            <?php echo Form::select('category_id', $categories, null, ['class'=>'form-control']); ?>

        </div>
        
        <div class="form-group">
            <?php echo Form::label('video_category_id', 'Category:'); ?>

            <?php echo Form::select('video_category_id', $video_categories, null, ['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('photo_id', 'Profile Photo:'); ?>

            <?php echo Form::file('photo_id', null, ['class'=>'form-control']); ?>

        </div>
        
        <div class="form-group">
            <?php echo Form::label('related_pics_ids', 'Related Pics:'); ?>

            <?php echo Form::text('related_pics_ids', null, ['class'=>'form-control', 'placeholder' => 'Enter More than one Pic IDs by separating them with a ,']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('related_video_links', 'Related Videos:'); ?>

            <?php echo Form::text('related_video_links', null, ['class'=>'form-control', 'placeholder' => 'Enter More than one Video Link by separating them with a ,']); ?>

        </div>
        
        <div class="form-group">
            <?php echo Form::label('price', 'Price:'); ?>

            <?php echo Form::number('price', null, ['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('gender[]', 'Gender:'); ?> <br>
            <div class="form-check col-md-6">
                <input type="checkbox" name="gender[]" value="male" class="form-check-input">
                <label class="form-check-label" for="male">Male</label><br>
            </div>
            <div class="form-check col-md-6">
                <input type="checkbox" name="gender[]" value="female" class="form-check-input">
                <label class="form-check-label" for="female">Female</label><br>
            </div>
        </div>


        
        <div class="form-group">
            <?php echo Form::label('age_range[]', 'Age Range:'); ?> <br>
            <div class="form-check col-md-6">
                <input type="checkbox" name="age_range[]" value="2-6 years" class="form-check-input">
                <label class="form-check-label" for="2-6 years">2-6 Years</label>
            </div>
            <div class="form-check col-md-6">
                <input type="checkbox" name="age_range[]" value="below 13 years" class="form-check-input">
                <label class="form-check-label" for="below 13 years">Below 13 years</label>
            </div>
            <div class="form-check col-md-6">
                <input type="checkbox" name="age_range[]" value="13 years and above" class="form-check-input">
                <label class="form-check-label" for="13 years and above">13 Years and Above</label>
            </div>
            <div class="form-check col-md-6">
                <input type="checkbox" name="age_range[]" value="18 years and above" class="form-check-input">
                <label class="form-check-label" for="18 years and above">18 Years and Above</label>
            </div>
        </div>
        
        
        
        <div class="form-group">
            <?php echo Form::label('selected_product_goals[]', 'Product Goals:'); ?> <br>
            <?php if($product_goals): ?>

                <?php $__currentLoopData = $product_goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check col-md-6">
                        <input type="checkbox" name="selected_product_goals[]" value="<?php echo e($product_goal->name); ?>" class="form-check-input">
                        <label class="form-check-label" for="<?php echo e($product_goal->name); ?>"><?php echo e($product_goal->name); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>

        <br>
        <br>
        <br>
        <br>
        <br>

        <div class="form-group">
            <?php echo Form::label('details', 'Details:'); ?>

            <?php echo Form::textarea('details', null, ['class'=>'form-control']); ?>

        </div>
        
        <div class="form-group">
            <?php echo Form::label('description', 'Description'); ?>

            <?php echo Form::textarea('description', null, ['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Create Product', ['class'=> 'btn btn-primary']); ?>

        </div>

        <?php echo Form::close(); ?>

    </div>

        <?php echo $__env->make('includes.form_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>