<script src="<?php echo e(asset('js/iziToast.js')); ?>"></script>
<?php echo $__env->make('vendor.lara-izitoast.toast', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- jQuery -->
<script src="<?php echo e(asset('js/libs.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
