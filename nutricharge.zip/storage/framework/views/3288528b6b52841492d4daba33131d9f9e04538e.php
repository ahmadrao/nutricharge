<?php if(isset($sidebar_products)): ?>
    <h2>Products </h2>
    <?php $__currentLoopData = $sidebar_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12">
            <a href="/product/<?php echo e($product->slug); ?>" style="color: inherit;">
                <div class="col-md-6">
                    <!-- Title -->
                    <h4 style="margin-left: -28px;"><?php echo e($product->title); ?></h4>
                    <!-- Product Price -->
                    <h5 style="margin-left: -27px;">Rs. <?php echo e($product->price); ?></h5>
                                      
                    

                </div>

                <div class="col-md-6">

                    <img class="img-responsive" style="margin-left: auto; margin-right: auto;" src="<?php echo e($product->photo ? $product->photo->file : 'http://placehold.it/700x200'); ?>" alt="">

                </div>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
