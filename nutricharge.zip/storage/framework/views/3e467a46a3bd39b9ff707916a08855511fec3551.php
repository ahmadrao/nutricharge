<?php $__env->startSection('content'); ?>

    <!-- Title -->
    <h1><?php echo e($post->title); ?></h1>

    <!-- Author -->
    <p class="lead">
        by <a href="#"><?php echo e($post->user->name); ?></a>
    </p>

    <hr>

    <?php if(Session::has('comment_message')): ?>

        <p class="bg-success"><?php echo e(session('comment_message')); ?></p>
    <?php endif; ?>

    <!-- Date/Time -->
    <p><span class="glyphicon glyphicon-time"></span> <?php echo e($post->created_at->diffForHumans()); ?></p>

    <hr>

    <!-- Preview Image -->
    <img height="500px" width="700px" class="img-responsive"
         src="<?php echo e($post->photo ? $post->photo->file: 'http://placehold.it/700x300'); ?>" alt="">

    <hr>

    <!-- Post Content -->
    <p class="lead"><?php echo $post->body; ?></p>

    <hr>


    <div id="disqus_thread"></div>

     <!-- Blog Comments -->
     <?php if(Auth::check()): ?>
        <!-- Comments Form -->
        <div class="well">
            <h4>Leave a Comment:</h4>
            <?php if(Session::has('reply_message')): ?>

                <p class="bg-success"><?php echo e(session('reply_message')); ?></p>

            <?php endif; ?>
            <?php echo Form::open(['method'=>'POST', 'action'=>'PostCommentsController@store']); ?>

            <div class="form-group">

                <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                <?php echo Form::label('body', 'Body:'); ?>

                <?php echo Form::textarea('body', null, ['class'=>'form-control', 'rows'=>3]); ?>

            </div>

            <div class="form-group">
                <?php echo Form::submit('Submit Comment', ['class'=> 'btn btn-primary']); ?>

            </div>

            <?php echo Form::close(); ?>

        </div>
    <?php endif; ?>
    <hr>

    <!-- Posted Comments -->
    <?php if(count($comments) > 0): ?>
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Comment -->
            <div class="media">
                <a class="pull-left" href="#">
                    <img class="media-object" height="64px" width="64px"
                         src="<?php echo e($comment->photo ? Gravatar::get($comment->email) : 'http://placehold.it/64x64'); ?>" alt="">
                </a>
                <div class="media-body">
                    <h4 class="media-heading"><?php echo e($comment->author); ?>

                        <small><?php echo e($comment->created_at->diffForHumans()); ?></small>
                    </h4>
                <?php echo e($comment->body); ?>

                    <div class="comment-reply-container">
                        <button id="toggle-reply" class="toggle-reply btn btn-primary pull-right" onclick="myFunction()">Reply</button>

                        <div id="comment-reply">
                            <?php echo Form::open(['method'=>'POST', 'action'=>'CommentRepliesController@createreply']); ?>

                            <input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>">
                            <div class="form-group">
                                <?php echo Form::label('body', 'Body:'); ?>

                                <?php echo Form::text('body', null, ['class'=>'form-control']); ?>

                            </div>

                            <div class="form-group">
                                <?php echo Form::submit('Submit Reply', ['class'=> 'btn btn-primary']); ?>

                            </div>

                            <?php echo Form::close(); ?>


                        </div>
                    </div>
                <!-- Nested Comment -->
                    <?php if(count($comment->replies) > 0 ): ?>
                        <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($reply->is_active == 1): ?>
                            <div id="media-reply" class="media">
                                <a class="pull-left" href="#">
                                    <img class="media-object" height="64" width="64"
                                         src="<?php echo e($reply->photo ? $reply->photo : 'http://placehold.it/64x64'); ?>" alt="">
                                </a>
                                <div class="media-body">
                                    <h4 class="media-heading"><?php echo e($reply->author); ?>

                                        <small><?php echo e($reply->created_at->diffForHumans()); ?></small>
                                    </h4>
                                    <?php echo e($reply->body); ?>

                                </div>
                            </div>
                            <div class="comment-reply-container">
                                <button id="toggle-reply" class="toggle-reply btn btn-primary pull-right" onclick="myFunction()">Reply</button>

                                <div id="comment-reply">
                                    <?php echo Form::open(['method'=>'POST', 'action'=>'CommentRepliesController@createreply']); ?>

                                    <input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>">
                                    <div class="form-group">
                                        <?php echo Form::label('body', 'Body:'); ?>

                                        <?php echo Form::text('body', null, ['class'=>'form-control']); ?>

                                    </div>

                                    <div class="form-group">
                                        <?php echo Form::submit('Submit Reply', ['class'=> 'btn btn-primary']); ?>

                                    </div>

                                    <?php echo Form::close(); ?>


                                </div>
                            </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>

        myFunction() {
        $(".toggle-reply").click(function () {
                    $(this).next().slideToggle("slow");
                });
        }
        
    </script>
<?php $__env->stopSection(); ?>





    




    


<?php echo $__env->make('layouts.blog-post', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>