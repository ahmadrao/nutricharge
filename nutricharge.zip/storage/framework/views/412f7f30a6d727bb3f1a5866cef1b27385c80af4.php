<!-- Header -->
<?php echo $__env->make('includes.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<body>

<!-- Navigation -->
<?php echo $__env->make('includes.front.home_nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page Content -->
<div class="container" id="app">

    <div class="row">

        <!--  Post Content Column -->
        <div class="col-md-9">

            <!--  Post -->

            <?php echo $__env->yieldContent('content'); ?>


        </div>



        <!--  Sidebar Widgets Column -->
        <?php echo $__env->make('includes.front.home_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </div>
    <!-- /.row -->

    <hr>

    <!-- Footer -->
    <?php echo $__env->make('includes.front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</div>
<!-- /.container -->

<script src="<?php echo e(asset('js/iziToast.js')); ?>"></script>
<?php echo $__env->make('vendor.lara-izitoast.toast', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- jQuery -->
<script src="<?php echo e(asset('js/libs.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>


</body>

</html>
