<?php $__env->startSection('content'); ?>
    <h1>Media</h1>

    <?php if(Session::has('photo_deleted')): ?>
        <p class="bg-danger"><?php echo e(session('photo_deleted')); ?></p>
    <?php endif; ?>





    <?php if($photos): ?>


        <form action="/admin/delete/media" method="get" class="form-inline">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('delete')); ?>

            <div class="form-group">
                <select name="checkBoxArray" id="" class="form-control">
                    <option value="delete">Delete</option>
                </select>
            </div>
            <div class="form-group">
                <input type="submit" class="form-control btn btn-primary">
            </div>


            <table class="table table-dark">
                <thead>
                <tr>
                    <th scope="col"><input type="checkbox" id="options"></th>
                    <th scope="col">#</th>
                    <th scope="col">Photo</th>
                    <th scope="col">Created At</th>
                    <th scope="col">Updated At</th>
                    <th scope="col">Delete Photo</th>

                </tr>
                </thead>
                <tbody>


                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><input type="checkbox" class="checkBoxes" name="checkBoxArray[]" value="<?php echo e($photo->id); ?>">
                        </td>
                        <th scope="row"><?php echo e($photo->id); ?></th>
                        <td><img height="70px" src="<?php echo e($photo->file ? $photo->file : 'http://placehold.it/400x400'); ?>"
                                 alt="">
                        </td>
                        <td><?php echo e($photo->created_at ? $photo->created_at->diffForHumans() : 'NO DATE'); ?></td>
                        <td><?php echo e($photo->updated_at ? $photo->updated_at->diffForHumans() : 'NO DATE'); ?></td>
                        <td>
                            <?php echo Form::open(['method'=>'DELETE', 'action'=>['AdminMediaController@destroy', $photo->id]]); ?>


                            <div class="form-group">
                                <?php echo Form::submit('DELETE', ['class'=> 'btn btn-danger']); ?>

                            </div>

                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            <?php else: ?>
                <h1>NO MEDIA FILES</h1>


            <?php endif; ?>

        </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
    $(document).ready(function(){

        $('#options').click(function () {

            if(this.checked){
                $('.checkBoxes').each(function () {
                    this.checked = true;
                });
            }else {
                $('.checkBoxes').each(function () {
                    this.checked = false;
                });
            }
        });

    });
    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>