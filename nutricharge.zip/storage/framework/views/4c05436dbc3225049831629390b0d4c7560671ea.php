<?php $__env->startSection('content'); ?>
    <a href="/admin/orders" class="btn btn-primary" style="margin-top: 6px;">Back to All Orders</a>
    <h1>Delivered Orders</h1>
    <table class="table table-dark">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Product Name</th>
            <th scope="col">Name</th>
            <th scope="col">Phone No.</th>
            <th scope="col">Email</th>
            <th scope="col">Price</th>
            <th scope="col">View Order</th>
            <th scope="col">Created At</th>
            <th scope="col">Delivered At</th>
        </tr>
        </thead>

        <?php if($orders): ?>

            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                <tr>
                    <th scope="row"><?php echo e($order->id); ?></th>
                    <td> <?php echo e($order->product->title); ?> </td>
                    <td><?php echo e($order->name); ?></td>
                    <td><?php echo e($order->phone_number); ?></td>
                    <td><?php echo e($order->email); ?></td>
                    <td><?php echo e($order->product->price); ?></td>
                    <td><a href="/admin/orders/<?php echo e($order->id); ?>" class="btn btn-success">View Order</a></td>
                    <td><?php echo e($order->created_at->diffForHumans()); ?></td>
                    <td><?php echo e($order->updated_at->diffForHumans()); ?></td>
                </tr>

                </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </table>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>