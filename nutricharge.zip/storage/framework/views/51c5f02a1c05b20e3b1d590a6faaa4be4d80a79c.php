<?php $__env->startSection('content'); ?>
    <h1>Edit User</h1>
    <?php echo $__env->make('includes.form_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo Form::model($user, ['method'=>'PATCH', 'action'=>['AdminUsersController@update', $user->id], 'files'=>true]); ?>


    <div class="col-md-3">
        <div class="form-group">
            <?php echo Form::label('photo_id', 'Your Image:'); ?>

            <img src="<?php echo e($user->photo ? $user->photo->file : 'http://placehold.it/400x400'); ?>" alt="" class="img-responsive img-rounded">
            <?php echo Form::file('photo_id', null, ['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-md-9">
        <div class="row form-group">
            <?php echo Form::label('name', 'Name:'); ?>

            <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name"
                   value="<?php echo e(old('name', $user->name)); ?>" required autofocus>

            <?php if($errors->has('name')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="row form-group">
            <?php echo Form::label('email', 'Email:'); ?>

            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                   name="email" value="<?php echo e(old('email')); ?>" required>

            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>

        </div>

        <div class="row form-group">
            <?php echo Form::label('password', 'Password:'); ?>

            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                   name="password" required>

            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>

        </div>

        <div class="row form-group">
            <?php echo Form::label('role_id', 'Role:'); ?>

            <?php echo Form::select('role_id', $roles, null, ['class'=>'form-control']); ?>

        </div>

        <div class="row form-group">
            <?php echo Form::label('is_active', 'Status:'); ?>

            <?php echo Form::select('is_active', array(0=>'Not Active', 1=>'Active'), null, ['class'=>'form-control']); ?>

        </div>

        <div class="row form-group">
            <?php echo Form::submit('Update User', ['class'=> 'btn btn-primary col-md-2']); ?>

        </div>

    </div>

    <div class="col-md-9">
        <?php echo Form::close(); ?>


        <?php echo Form::open(['method'=>'DELETE', 'action'=>['AdminUsersController@destroy', $user->id]]); ?>


            <div class="row pull-right form-group">
                <?php echo Form::submit('Delete User', ['class'=> 'btn btn-danger mb-141']); ?>

            </div>

        <?php echo Form::close(); ?>

    </div>
    
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>