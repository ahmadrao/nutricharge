<?php $__env->startSection('content'); ?>
    <h1>PRODUCT GOALS</h1>


    <div class="col-sm-6">
        <h3>Update Product Goals</h3>


        <?php echo Form::model($product_goal, ['method'=>'PATCH', 'action'=>['AdminProductGoalsController@update', $product_goal->id]]); ?>

        <div class="form-group">
            <?php echo Form::label('name', 'Name:'); ?>

            <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Update Product Goal', ['class'=> 'btn btn-primary']); ?>

        </div>

        <?php echo Form::close(); ?>


    </div>
    <div class="col-sm-6">
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>