<?php $__env->startSection('content'); ?>

    <?php if(Session::has('deleted_user')): ?>

        <p class="bg-danger"><?php echo e(session('deleted_user')); ?></p>
    <?php endif; ?>
    <h1>Users</h1>
    <?php if($users): ?>
        <div class="table-responsive-sm">
            <table class="table table-dark">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Image</th>
                    <th scope="col">Email</th>
                    <th scope="col">Role</th>
                    <th scope="col">Status</th>
                    <th scope="col">Created At</th>
                    <th scope="col">Updated At</th>
                </tr>
                </thead>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                    <tr>
                        <th scope="row"><?php echo e($user->id); ?></th>
                        <td><?php echo e($user->name); ?></td>
                        <td><a href="/admin/users/<?php echo e($user->id); ?>/edit"><img height="70" src="<?php echo e($user->photo ? $user->photo->file : 'No picture exists'); ?>" alt=""></a></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->role->name); ?></td>
                        <td><?php echo e($user->is_active == 1 ? 'Active' : 'Not Active'); ?></td>
                        <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                        <td><?php echo e($user->updated_at->diffForHumans()); ?></td>
                    </tr>

                    </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    <?php endif; ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>