<?php $__env->startSection('content'); ?>
    <a href="/admin/orders" class="btn btn-primary" style="margin-top: 6px;">Back to All Orders</a>
    <h1> <?php echo e($order->product->title); ?> Order</h1>
    
    <h2>Buyer Name:</h2>
    <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->name); ?></h4>
    <h2>Buyer Email:</h2>
    <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->email); ?></h4> 
    <h2>Product Price:</h2> 
    <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->product->price); ?></h4>  
    <h2>Buyer Phone Number:</h2>           
    <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->phone_number); ?></h4>
    <h2>Buyer Address:</h2>
    <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->address); ?></h4>
    <h2>Order was Created At:</h2>
    <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($order->created_at->diffForHumans()); ?></h4>
                    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>