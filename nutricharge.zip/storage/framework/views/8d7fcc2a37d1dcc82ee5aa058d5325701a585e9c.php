<?php $__env->startSection('content'); ?>
    <h1>Orders</h1>
    <?php if(Session::has('order_updated')): ?>

        <p class="bg-success"><?php echo e(session('order_updated')); ?></p>
    <?php endif; ?>
    <table class="table table-dark">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Product Name</th>
            <th scope="col">Name</th>
            <th scope="col">Phone No.</th>
            <th scope="col">Email</th>
            <th scope="col">Address</th>
            <th scope="col">View Order</th>
            <th scope="col">Mark As</th>
            <th scope="col">Created At</th>
            <th scope="col">Updated At</th>
        </tr>
        </thead>

        <?php if($orders): ?>

            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                <tr>
                    <th scope="row"><?php echo e($order->id); ?></th>
                    <td> <?php echo e($order->product->title); ?> </td>
                    <td><?php echo e($order->name); ?></td>
                    <td><?php echo e($order->phone_number); ?></td>
                    <td><?php echo e($order->email); ?></td>
                    <td><?php echo e($order->address); ?></td>
                    <td><a href="/admin/orders/<?php echo e($order->id); ?>" class="btn btn-success">View Order</a></td>
                    <?php echo Form::model($order, ['method'=>'PATCH', 'action'=>['OrderController@update', $order->id]]); ?>

                        <td>
                            <div class="form-group">
                                <?php echo Form::submit( $order->is_delivered  ? "Un Delivered" : "Delivered", ['class'=> 'btn btn-info']); ?>

                            </div>
                        </td>

                    <?php echo Form::close(); ?>

                    <td><?php echo e($order->created_at->diffForHumans()); ?></td>
                    <td><?php echo e($order->updated_at->diffForHumans()); ?></td>
                </tr>

                </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </table>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>