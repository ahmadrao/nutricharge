<div class="col-md-3">

    
    <!-- Product Related Videos -->
    <?php if(isset($related_videos)): ?>
            <h2>Product Videos</h2>
            <div class="row">
                           
                <?php $__currentLoopData = $related_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12">
                        <iframe width="100%" height="100%" src="<?php echo e($video->link); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- /.row -->
    <?php endif; ?>

    <!--Sidebar Product -->
    <?php echo $__env->make('includes.front.sidebar_products', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>
