<?php $__env->startSection('content'); ?>
    <h1>Contacts</h1>
    <table class="table table-dark">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Address</th>
            <th scope="col">Message</th>
            <th scope="col">Submitted</th>
        </tr>
        </thead>

        <?php if($contacts): ?>

            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                <tr>
                    <th scope="row"><?php echo e($contact->id); ?></th>
                    
                    <td><?php echo e($contact->name); ?></td>
                    <td><?php echo e($contact->email); ?></td>
                    <td><?php echo e($contact->address); ?></td>
                    <td><?php echo e(str_limit($contact->message, 50)); ?></td>
                    <td><?php echo e($contact->created_at->diffForHumans()); ?></td>
                </tr>

                </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </table>
    <div class="row">
        <div class="col-sm-6 col-sm-offset-6">
            <?php echo e($contacts->render()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>