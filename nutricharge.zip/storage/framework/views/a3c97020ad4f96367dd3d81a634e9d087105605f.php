<?php $__env->startSection('content'); ?>
    <h1>Create User</h1>

    <?php echo Form::open(['method'=>'POST', 'action'=>'AdminUsersController@store', 'files'=>true]); ?>


    <div class="col-md-4">
        <div class="form-group">
            <?php echo Form::label('photo_id', 'Select Your Image:'); ?>

            <?php echo Form::file('photo_id', null, ['class'=>'form-control']); ?>

        </div>
    </div>
    <div class="col-md-8">
        <div class="row form-group">
            <?php echo Form::label('name', 'Name:'); ?>

            <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name"
                   value="<?php echo e(old('name')); ?>" required autofocus>

            <?php if($errors->has('name')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="row form-group">
            <?php echo Form::label('email', 'Email:'); ?>

            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                   name="email" value="<?php echo e(old('email')); ?>" required>

            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>

        </div>

        <div class="row form-group">
            <?php echo Form::label('password', 'Password:'); ?>

            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                   name="password" required>

            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>

        </div>

        <div class="row form-group">
            <?php echo Form::label('role_id', 'Role:'); ?>

            <?php echo Form::select('role_id', [''=>'Choose Options']+ $roles, 0, ['class'=>'form-control']); ?>

        </div>

        <div class="row form-group">
            <?php echo Form::label('is_active', 'Status:'); ?>

            <?php echo Form::select('is_active', array(0=>'Not Active', 1=>'Active'), 0, ['class'=>'form-control']); ?>

        </div>

        <div class="pull-left form-group">
            <?php echo Form::submit('Create User', ['class'=> 'btn btn-primary']); ?>

        </div>

    </div>


    <?php echo Form::close(); ?>

    
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>