<?php $__env->startSection('content'); ?>
    <h1>VIDEOS</h1>

    <!-- Create Video -->
    <div class="col-sm-6">
        <h3>Create Video</h3>


        <?php echo Form::open(['method'=>'POST', 'action'=>'VideoController@store']); ?>

        <div class="form-group">
            <?php echo Form::label('name', 'Name:'); ?>

            <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('video_category_id', 'Video Category:'); ?>

            <?php echo Form::select('video_category_id', $categories, null, ['class'=>'form-control']); ?>

        </div>
        
        <div class="form-group">
            <?php echo Form::label('link', 'Youtube Video Iframe Link:'); ?>

            <?php echo Form::text('link', null, ['class'=>'form-control', 'placeholder'=>'Enter Youtube Video Iframe Link i.e youtube.com/embed/akdjfW89']); ?>

        </div>

        

        <div class="form-group">
            <?php echo Form::submit('Create Video', ['class'=> 'btn btn-primary']); ?>

        </div>

        <?php echo Form::close(); ?>


    </div>


    <!-- Show All Videos -->
    <div class="col-sm-6">


        <table class="table table-dark">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Category</th>
                <th scope="col">Created At</th>
                <th scope="col">Updated At</th>
                <th scope="col">EDIT</th>
                <th scope="col">DELETE</th>
            </tr>
            </thead>
            <tbody>

            <?php if($videos): ?>

                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($video->id); ?></th>
                        <td><?php echo e($video->name); ?></td>
                        <td><?php echo e($video->category->name); ?></td>
                        <td><?php echo e($video->created_at ? $video->created_at->diffForHumans() : 'NOT PROVIDED'); ?></td>
                        <td><?php echo e($video->updated_at ? $video->updated_at->diffForHumans() : 'NOT PROVIDED'); ?></td>
                        <td><a href="/admin/videos/<?php echo e($video->id); ?>/edit" class="btn btn-outline-primary">Edit</a>
                        </td>
                        <td>
                            <?php echo Form::open(['method'=>'DELETE', 'action'=>['VideoCategoryController@destroy', $video->id]]); ?>


                            <div class="form-group">
                                <?php echo Form::submit('Delete', ['class'=> 'btn btn-outline-danger']); ?>

                            </div>

                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            </tbody>
        </table>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>