<div class="row">

   <h2>Related Products</h2>

    <?php if(isset($related_products)): ?>
        <?php $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 text-center">
                <a href="/product/<?php echo e($product->slug); ?>" style="color: inherit;">
                    <figure class="card card-product">
                        <div class="img-wrap"> 
                            <img src="<?php echo e($product->photo ? $product->photo->file : 'http://placehold.it/700x200'); ?>">
                        </div>
                        <figcaption class="info-wrap">
                            <h6 class="title text-dots"><?php echo e($product->title); ?></h6>
                            <div class="action-wrap">
                                <div class="price-wrap h5">
                                    <span class="price-new">Rs. <?php echo e($product->price); ?></span>
                                    <span class="">
                                        <?php if($product->getStarRating()): ?>
                                            <?php for($i=1; $i <= 5 ; $i++): ?>
                                                <span class="glyphicon glyphicon-star<?php echo e(($i <= $product->getStarRating()) ? '' : '-empty'); ?>"></span>
                                            <?php endfor; ?>
                                        <?php endif; ?>
                                    </span>
                                </div> 
                            </div> <!-- action-wrap -->
                        </figcaption>
                    </figure> <!-- card // -->
                </a>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

</div>