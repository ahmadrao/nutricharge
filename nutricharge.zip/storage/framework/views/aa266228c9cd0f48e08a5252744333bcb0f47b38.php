<!-- Header -->
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

<!-- Navigation -->
<?php echo $__env->make('includes.home_nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page Content -->
<div class="container">

    <div class="row">

        <!-- Blog Post Content Column -->
        <div class="col-lg-8">

            <!-- Blog Post -->

            <?php echo $__env->yieldContent('content'); ?>

        </div>

        <!-- Blog Sidebar Widgets Column -->
        <?php echo $__env->make('includes.home_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </div>
    <!-- /.row -->

    <hr>

    <!-- Footer -->
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    

</div>
<!-- /.container -->

<?php echo $__env->yieldContent('scripts'); ?>
<!-- jQuery -->
<script src="<?php echo e(asset('js/libs.js')); ?>"></script>


</body>

</html>
