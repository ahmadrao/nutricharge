<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('includes.admin.tinyeditor', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <h1>Edit Product</h1>
    <div class="row">
        <?php echo $__env->make('includes.form_error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo Form::model($product, ['method'=>'PATCH', 'action'=>['AdminProductsController@update', $product->id], 'files'=>true]); ?>


        <div class="col-md-3">
            <div class="form-group">
                <?php echo Form::label('photo_id', 'Product Image:'); ?>

                <img src="<?php echo e($product->photo ? $product->photo->file : 'http://placehold.it/400x400'); ?>" alt="" class="img-responsive img-rounded">
                <?php echo Form::file('photo_id', null, ['class'=>'form-control']); ?>

            </div>
        </div>

        <div class="col-md-9">
            <div class="form-group">
                <?php echo Form::label('title', 'Title:'); ?>

                <?php echo Form::text('title', null, ['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('category_id', 'Category:'); ?>

                <?php echo Form::select('category_id', $categories, null, ['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('video_category_id', 'Video Category:'); ?>

                <?php echo Form::select('video_category_id', $video_categories, null, ['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('related_pics_ids', 'Related Pics:'); ?>

                <?php echo Form::text('related_pics_ids', null, ['class'=>'form-control', 'placeholder' => 'Enter More than one Pic IDs by separating them with a ,']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('related_video_links', 'Related Videos:'); ?>

                <?php echo Form::text('related_video_links', null, ['class'=>'form-control', 'placeholder' => 'Enter More than one Video Link by separating them with a ,']); ?>

            </div>
            
            <div class="form-group">
                <?php echo Form::label('price', 'Price:'); ?>

                <?php echo Form::number('price', null, ['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('gender[]', 'Gender:'); ?> <br>
                <div class="form-check col-md-6">
                    <input type="checkbox" name="gender[]" value="male" <?php echo e(in_array("male", $gender)?"checked":""); ?> class="form-check-input">
                    <label class="form-check-label" for="male">Male</label><br>
                </div>
                <div class="form-check col-md-6">
                    <input type="checkbox" name="gender[]" value="female" <?php echo e(in_array("female", $gender)?"checked":""); ?> class="form-check-input">
                    <label class="form-check-label" for="female">Female</label><br>
                </div>
            </div>

        
        <div class="form-group">
            <?php echo Form::label('age_range[]', 'Age Range:'); ?> <br>
            <div class="form-check col-md-6">
                <input type="checkbox" name="age_range[]" value="2-6 years" <?php echo e(in_array("2-6 years", $age_range)?"checked":""); ?> class="form-check-input">
                <label class="form-check-label" for="2-6 years">2-6 Years</label><br>
            </div>
            <div class="form-check col-md-6">
                <input type="checkbox" name="age_range[]" value="below 13 years" <?php echo e(in_array("below 13 years", $age_range)?"checked":""); ?> class="form-check-input">
                <label class="form-check-label" for="below 13 years">Below 13 years</label><br>
            </div>
            <div class="form-check col-md-6">
                <input type="checkbox" name="age_range[]" value="13 years and above" <?php echo e(in_array("13 years and above", $age_range)?"checked":""); ?> class="form-check-input">
                <label class="form-check-label" for="13 years and above">13 Years and Above</label><br>
            </div>
            <div class="form-check col-md-6">
                <input type="checkbox" name="age_range[]" value="18 years and above" <?php echo e(in_array("18 years and above", $age_range)?"checked":""); ?> class="form-check-input">
                <label class="form-check-label" for="18 years and above">18 Years and Above</label><br>
            </div>
        </div>
        
        
        
        <div class="form-group">
            <?php echo Form::label('selected_product_goals[]', 'Product Goals:'); ?> <br>
            <?php if($product_goals): ?>

                <?php $__currentLoopData = $product_goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check col-md-6">
                        <input type="checkbox" name="selected_product_goals[]" value="<?php echo e($product_goal->name); ?>" <?php echo e(in_array($product_goal->name, $selected_product_goals)?"checked":""); ?> class="form-check-input">
                        <label class="form-check-label" for="<?php echo e($product_goal->name); ?>"><?php echo e($product_goal->name); ?></label><br>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>


        <br>
        <br>
        <br>
        <br>
        <br>

        <div class="form-group">
            <?php echo Form::label('details', 'Details:'); ?>

            <?php echo Form::textarea('details', null, ['class'=>'form-control']); ?>

        </div>
        
        <div class="form-group">
            <?php echo Form::label('description', 'Description'); ?>

            <?php echo Form::textarea('description', null, ['class'=>'form-control']); ?>

        </div>

            <div class="form-group">
                <?php echo Form::submit('Update Product', ['class'=> 'btn btn-success col-md-6']); ?>

            </div>

            <?php echo Form::close(); ?>


            <?php echo Form::open(['method'=>'DELETE', 'action'=>['AdminProductsController@destroy', $product->id]]); ?>


            <div class="form-group">
                <?php echo Form::submit('Delete Product', ['class'=> 'btn btn-danger col-md-6']); ?>

            </div>

            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>