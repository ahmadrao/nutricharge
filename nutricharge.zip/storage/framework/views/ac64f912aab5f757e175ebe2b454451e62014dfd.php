<!-- Header -->
<?php echo $__env->make('includes.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<body>

<!-- Navigation -->
<?php echo $__env->make('includes.front.home_nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- Page Content -->
<div class="container">

    <!-- Find Your Nutricharge Section -->
    

    <!--  Slider -->
    <?php echo $__env->make('includes.front.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="row">

        <h1>Nutricharge Products</h1>


        <!--  Products  -->
        <?php if($products): ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <a href="/product/<?php echo e($product->slug); ?>" style="color: inherit;">
                        <figure class="card card-product">
                            <div class="img-wrap"> 
                                <img src="<?php echo e($product->photo ? $product->photo->file : 'http://placehold.it/700x200'); ?>">
                            </div>
                            <figcaption class="info-wrap">
                                <h6 class="title text-dots"><?php echo e($product->title); ?></h6>
                                <div class="action-wrap">
                                    <div class="price-wrap h5">
                                        <span class="price-new">Rs. <?php echo e($product->price); ?></span>
                                        <span class="">
                                            <?php if($product->getStarRating()): ?>
                                                <?php for($i=1; $i <= 5 ; $i++): ?>
                                                    <span class="glyphicon glyphicon-star<?php echo e(($i <= $product->getStarRating()) ? '' : '-empty'); ?>"></span>
                                                <?php endfor; ?>
                                            <?php endif; ?>
                                        </span>
                                    </div> 
                                </div> <!-- action-wrap -->
                            </figcaption>
                        </figure> <!-- card // -->
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <h2>No Products</h2>
    <?php endif; ?>
    <!-- Pagination -->




    </div>
    <!-- /.row -->

    <hr>

    <!-- Pagination -->
    

    <!-- Footer -->
    <?php echo $__env->make('includes.front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>
<!-- /.container -->


<!-- jQuery -->
<script src="<?php echo e(asset('js/libs.js')); ?>"></script>


<script>

    // $('#search-goal').on('change', function(e) {
    //     console.log(e);
    //     var age_range = e.target.value;
        
    //     console.log(age_range);
    // })


</script>


</body>

</html>
