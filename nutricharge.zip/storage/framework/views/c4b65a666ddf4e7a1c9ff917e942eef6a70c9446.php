<!-- Header -->
<?php echo $__env->make('includes.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

<!-- Navigation -->
<?php echo $__env->make('includes.front.home_nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- Page Content -->
<div class="container">

    <div class="row">
        <div class="col-md-12" >
            <img src="<?php echo e(asset('images/geometic-bg-white.jpg')); ?>" alt="<?php echo e($category_name); ?>" class="img-responsive">
            <div class="carousel-caption">
                <h1><?php echo e($category_name); ?></h1>
            </div>
        </div>
        <?php if($videos): ?> 
            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <h2><?php echo e($video->name); ?></h2>
                    <iframe width="100%" height="100%" src="<?php echo e($video->link); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        
    </div>
    <!-- /.row -->

    <hr>


    <!-- Footer -->
    <?php echo $__env->make('includes.front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>
<!-- /.container -->


<!-- jQuery -->
<script src="<?php echo e(asset('js/libs.js')); ?>"></script>





</body>

</html>
