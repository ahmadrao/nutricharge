<?php $__env->startSection('content'); ?>

    <!-- Title -->
    <h1><?php echo e($product->title); ?></h1>

    <!-- Author -->
    <p class="lead">
        by <a href="#"><?php echo e($product->user->name); ?></a>
    </p>

    <hr>

    <?php if(Session::has('review_message')): ?>

        <p class="bg-success"><?php echo e(session('review_message')); ?></p>
    <?php endif; ?>

    <!-- Date/Time -->
    <p><span class="glyphicon glyphicon-time"></span> <?php echo e($product->created_at->diffForHumans()); ?></p>

    <hr>

    <!-- Preview Image -->
    <img height="500px" width="700px" class="img-responsive"
         src="<?php echo e($product->photo ? $product->photo->file: 'http://placehold.it/700x300'); ?>" alt="">

    <hr>

    <!-- Product Content -->
    <p class="lead"><?php echo $product->body; ?></p>

    <hr>



     <!--  Reviews -->
     <?php if(Auth::check()): ?>
        <!-- Reviews Form -->
        <div class="well">
            <h4>Leave a Review:</h4>
            <?php if(Session::has('reply_message')): ?>

                <p class="bg-success"><?php echo e(session('reply_message')); ?></p>

            <?php endif; ?>
            <?php echo Form::open(['method'=>'POST', 'action'=>'ProductReviewsController@store']); ?>

            <div class="form-group">

                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                <?php echo Form::label('body', 'Body:'); ?>

                <?php echo Form::textarea('body', null, ['class'=>'form-control', 'rows'=>3]); ?>

            </div>

            <div class="form-group">
                <?php echo Form::submit('Submit Review', ['class'=> 'btn btn-primary']); ?>

            </div>

            <?php echo Form::close(); ?>

        </div>
    <?php endif; ?>
    <hr>

    

<?php $__env->stopSection(); ?>







    




    


<?php echo $__env->make('layouts.single-product', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>