<?php $__env->startSection('content'); ?>
    <h1>Posts</h1>
    <?php if(Session::has('post_deleted')): ?>

        <p class="bg-danger"><?php echo e(session('post_deleted')); ?></p>
    <?php endif; ?>
    <table class="table table-dark">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Photo</th>
            <th scope="col">User</th>
            <th scope="col">Category</th>
            <th scope="col">Title</th>
            <th scope="col">Body</th>
            <th scope="col">View Post</th>
            <th scope="col">Created At</th>
            <th scope="col">Updated At</th>
        </tr>
        </thead>

        <?php if($posts): ?>

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                <tr>
                    <th scope="row"><?php echo e($post->id); ?></th>
                    <td><a href="/admin/posts/<?php echo e($post->id); ?>/edit"><img height="50px" src="<?php echo e($post->photo ? $post->photo->file : 'http://placehold.it/400x400'); ?>" alt=""></a></td>
                    <td><?php echo e($post->user->name); ?></td>
                    <td><?php echo e($post->category ? $post->category->name : "Undefined Category"); ?></td>
                    <td><?php echo e($post->title); ?></td>
                    <td><?php echo e(str_limit($post->body, 20)); ?></td>
                    <td><a href="/post/<?php echo e($post->slug); ?>" class="btn btn-success">View Post</a></td>
                    <td><a href="/admin/comments/<?php echo e($post->id); ?>" class="btn btn-info">Comments</a></td>
                    <td><?php echo e($post->created_at->diffForHumans()); ?></td>
                    <td><?php echo e($post->updated_at->diffForHumans()); ?></td>
                </tr>

                </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </table>
    <div class="row">
        <div class="col-sm-6 col-sm-offset-6">
            <?php echo e($posts->render()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>