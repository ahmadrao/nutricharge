<!-- Header -->
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

<!-- Navigation -->
<?php echo $__env->make('includes.home_nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- Page Content -->
<div class="container">

    <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-9">


            <!-- Blog Products  -->
            <?php if($products): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6" >
                        <h2>
                            <?php echo e($product->title); ?>

                        </h2>
                        <p class="lead">
                            by <?php echo e($product->user->name); ?>

                        </p>
                        <p><span class="glyphicon glyphicon-time"></span><?php echo e($product->created_at->diffForHumans()); ?></p>
                        <hr>
                        <img class="img-responsive" src="<?php echo e($product->photo ? $product->photo->file : 'http://placehold.it/700x200'); ?>" alt="">
                        <hr>
                        <p><?php echo e(str_limit($product->body, 30)); ?></p>
                        <a class="btn btn-primary" href="/product/<?php echo e($product->slug); ?>">Read More <span
                                class="glyphicon glyphicon-chevron-right"></span></a>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h2>No Products</h2>
        <?php endif; ?>
        <!-- Pagination -->


        </div>

        <!-- Blog Sidebar Widgets Column -->
        <?php echo $__env->make('includes.home_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </div>
    <!-- /.row -->

    <hr>

    <div class="row">
        <div class="col-sm-6 col-sm-offset-5">
            <?php echo e($products->render()); ?>

        </div>
    </div>

    <!-- Footer -->
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>
<!-- /.container -->

<!-- jQuery -->
<script src="js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

</body>

</html>
