<?php $__env->startSection('content'); ?>
    <h1>Products</h1>
    <?php if(Session::has('product_deleted')): ?>

        <p class="bg-danger"><?php echo e(session('product_deleted')); ?></p>
    <?php endif; ?>
    <table class="table table-dark">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Photo</th>
            <th scope="col">User</th>
            <th scope="col">Category</th>
            <th scope="col">Title</th>
            <th scope="col">Body</th>
            <th scope="col">View Product</th>
            <th scope="col">Reviews</th>
            <th scope="col">Created At</th>
            <th scope="col">Updated At</th>
        </tr>
        </thead>

        <?php if($products): ?>

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                <tr>
                    <th scope="row"><?php echo e($product->id); ?></th>
                    <td><a href="/admin/products/<?php echo e($product->id); ?>/edit"><img height="50px" src="<?php echo e($product->photo
                    
                    
                     ? $product->photo->file : 'http://placehold.it/400x400'); ?>" alt=""></a></td>
                    <td><?php echo e($product->user->name); ?></td>
                    <td><?php echo e($product->category ? $product->category->name : "Undefined Category"); ?></td>
                    <td><?php echo e($product->title); ?></td>
                    <td><?php echo e(str_limit($product->body, 20)); ?></td>
                    <td><a href="/product/<?php echo e($product->slug); ?>" class="btn btn-success">View Product</a></td>
                    <td><a href="/admin/reviews/<?php echo e($product->id); ?>" class="btn btn-info">Reviews</a></td>
                    <td><?php echo e($product->created_at->diffForHumans()); ?></td>
                    <td><?php echo e($product->updated_at->diffForHumans()); ?></td>
                </tr>

                </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </table>
    <div class="row">
        <div class="col-sm-6 col-sm-offset-6">
            <?php echo e($products->render()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>